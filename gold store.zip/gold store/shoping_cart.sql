-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 09, 2021 at 06:47 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.3.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shoping_cart`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_data`
--

CREATE TABLE `admin_data` (
  `id` int(11) NOT NULL,
  `FirstName` varchar(200) NOT NULL,
  `LastName` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin_data`
--

INSERT INTO `admin_data` (`id`, `FirstName`, `LastName`, `email`, `password`) VALUES
(1, 'Saurabh', 'Jadhav', 'admin@gmail.com', '21232f297a57a5a743894a0e4a801fc3');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `cat_id` int(11) NOT NULL,
  `cat_name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`cat_id`, `cat_name`) VALUES
(4, 'school bags'),
(5, 'laptop bags'),
(6, 'travel bags'),
(7, 'Hand bags');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `totalprice` varchar(200) NOT NULL,
  `orderstatus` varchar(255) NOT NULL,
  `paymentmode` varchar(255) NOT NULL,
  `timestamp` timestamp(6) NOT NULL DEFAULT current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `userid`, `totalprice`, `orderstatus`, `paymentmode`, `timestamp`) VALUES
(59, 2, '4000', 'Cancelled', 'Online Payment', '2021-03-26 18:27:28.638982'),
(60, 7, '799', 'Order Placed', 'Online Payment', '2021-03-27 06:15:32.191134'),
(61, 8, '799', 'Cancelled', 'Online Payment', '2021-03-27 10:48:57.260747'),
(62, 8, '5598', 'Order Placed', 'Online Payment', '2021-03-27 10:55:10.749533'),
(63, 2, '799', 'Order Placed', 'Online Payment', '2021-04-05 04:24:46.032143'),
(64, 2, '799', 'Order Placed', 'Online Payment', '2021-04-08 06:21:55.321525'),
(65, 2, '799', 'Cancelled', 'Online Payment', '2021-04-09 16:44:02.590332');

-- --------------------------------------------------------

--
-- Table structure for table `ordersitems`
--

CREATE TABLE `ordersitems` (
  `orderid` int(11) NOT NULL,
  `productid` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `productprice` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ordersitems`
--

INSERT INTO `ordersitems` (`orderid`, `productid`, `quantity`, `productprice`) VALUES
(1, 1, 1, 799),
(2, 1, 1, 799),
(3, 1, 1, 799),
(4, 2, 1, 600),
(12, 2, 1, 600),
(13, 20, 1, 0),
(14, 2, 1, 600),
(15, 0, 1, 0),
(16, 0, 1, 0),
(23, 2, 1, 600),
(24, 2, 1, 600),
(25, 2, 1, 600),
(26, 1, 1, 799),
(27, 2, 1, 600),
(28, 2, 1, 600),
(29, 2, 1, 600),
(30, 1, 1, 799),
(31, 1, 1, 799),
(32, 9, 1, 5678),
(33, 9, 3, 5678),
(34, 10, 4, 3000),
(35, 10, 1, 0),
(40, 11, 1, 799),
(41, 11, 1, 799),
(42, 11, 1, 799),
(45, 11, 1, 799),
(47, 11, 1, 799),
(49, 11, 1, 799),
(50, 11, 1, 799),
(52, 11, 1, 799),
(53, 11, 1, 799),
(54, 11, 1, 799),
(55, 11, 1, 799),
(56, 12, 2, 799),
(57, 13, 1, 899),
(58, 11, 2, 799),
(59, 20, 1, 4000),
(60, 12, 1, 799),
(61, 12, 1, 799),
(62, 20, 1, 4000),
(63, 11, 1, 799),
(64, 12, 1, 799),
(65, 12, 1, 799);

-- --------------------------------------------------------

--
-- Table structure for table `orderstracking`
--

CREATE TABLE `orderstracking` (
  `id` int(11) NOT NULL,
  `orderid` int(11) NOT NULL,
  `status` varchar(255) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `timestamp` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orderstracking`
--

INSERT INTO `orderstracking` (`id`, `orderid`, `status`, `reason`, `timestamp`) VALUES
(1, 1, 'Dispatched', 'ggdh', '2021-03-03 10:15:53'),
(2, 1, 'cancelled', 'ttt', '2021-03-03 10:16:09'),
(3, 2, 'Dispatched', '', '2021-03-03 10:20:56'),
(4, 3, 'Dispatched', '', '2021-03-03 15:18:23'),
(5, 3, 'cancelled', '', '2021-03-03 15:18:55'),
(6, 2, 'Delivered', '', '2021-03-04 16:58:12'),
(7, 27, 'cancelled', 'dont like the product', '2021-03-18 10:19:39'),
(8, 30, 'Dispatched', 'your product has been dispatched', '2021-03-22 19:27:26'),
(9, 32, 'Dispatched', '', '2021-03-24 13:20:35'),
(10, 33, 'Dispatched', '', '2021-03-24 13:21:02'),
(11, 41, 'Dispatched', 'whyyy', '2021-03-25 11:46:53'),
(12, 50, 'Dispatched', 'baska bhava', '2021-03-25 11:49:30'),
(13, 4, 'cancelled', '', '2021-03-25 11:51:30'),
(14, 58, 'Dispatched', 'ur product has been dispatched', '2021-03-26 16:43:46'),
(15, 58, 'cancelled', '', '2021-03-26 16:44:27'),
(16, 59, 'Dispatched', 'your product has been dispatched', '2021-03-26 23:58:32'),
(17, 59, 'cancelled', 'i dont like the product', '2021-03-26 23:59:04'),
(18, 61, 'Dispatched', 'your product has been dispatched', '2021-03-27 16:20:33'),
(19, 61, 'cancelled', 'i dont like the product', '2021-03-27 16:21:10'),
(20, 65, 'Dispatched', '', '2021-04-09 22:14:57'),
(21, 65, 'cancelled', 'i dont like it', '2021-04-09 22:15:30');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `product_name` varchar(200) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `price` varchar(200) NOT NULL,
  `thumb` varchar(200) NOT NULL,
  `product_description` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_name`, `cat_id`, `price`, `thumb`, `product_description`) VALUES
(11, ' School Bag 1', 4, '799', 'uploads/At1.jpg', '  Addition Information\r\n2 large compartments\r\n1 front pocket (quick access pocket)\r\n15.6-inch laptop compatible\r\nElaborate Organizer pocket\r\nChest Strap & Anti-Theft Feature\r\nReflective Branding\r\nColo'),
(12, 'school bag 2', 4, '799', 'uploads/xenon 1.jpg', 'Addition Information\r\n2 large compartments\r\n1 front pocket (quick access pocket)\r\n15.6-inch laptop compatible\r\nElaborate Organizer pocket\r\nChest Strap & Anti-Theft Feature\r\nReflective Branding\r\nColor:'),
(13, 'School Bag 3', 4, '899', 'uploads/school bag 3.jpg', 'Capacity: 34 Litres, Weight: 0.62kg; Dimensions: 48cm x 33cm x 21cm, Quality: best quality as it is perfectly designed and made from high-quality lightweight nylon and double dotted waterproof polyest'),
(14, 'School Bag 4', 4, '2999', 'uploads/school bag 4.jpg', 'Outer Material: Polyester, Color: Black\r\nCapacity: 45 liters; Weight: 1000 grams; Dimensions: 60 cms x 24 cms x 36 cms (LxWxH)\r\nLock Type: Butterfly Lock, Number of compartments: 2\r\nLaptop Compatibili'),
(15, 'Laptop Bag 1', 5, '899', 'uploads/Laptop Bag 1.jpg', 'Type: Laptop Hand-held Bag\r\nCapacity: Any 15.6 Inch laptop\r\nMaterial: Polyester\r\n2 Compartments\r\nWater Resistant '),
(16, 'Laptop Bag 2', 5, '400', 'uploads/Laptop 2.jpeg', '\r\nType: Laptop Hand-held Bag\r\nCapacity: Any 15.6 Inch laptop\r\nMaterial: Polyester\r\n2 Compartments\r\nWater Resistant'),
(17, 'Laptop Bag 3', 5, '500', 'uploads/laptop bag 3.jpeg', '  \r\nType: Laptop Hand-held Bag\r\nCapacity: Any 15.6 Inch laptop\r\nMaterial: Polyester\r\n2 Compartments\r\nWater Resistant '),
(18, 'Laptop Bag 4', 5, '899', 'uploads/Laptop Bag 4.jpeg', '\r\n\r\n25 cm\r\nExternal Depth\r\n2 inch\r\nClosure\r\nZipper\r\nExpandable Features\r\nNo\r\nWeight\r\n220 g '),
(19, 'Travel Bag 1', 6, '3000', 'uploads/Travel Bag 4.jpg', 'Red textured hardside check-in trolley suitcase, secured with a fixed combination lock\r\nNo. of wheels: 4\r\nOne handle on top and one on the side\r\nPush button trolley\r\n360 degree wheeling system\r\nPush b'),
(20, 'Travel Bag 2', 6, '4000', 'uploads/travel bag 2.jpg', 'Sea-green textured hard-sided large trolley suitcase secured with a number lock\r\nOne top handle, one handle on the side and one top retractable trolley handle\r\n360-degree rotatable corner-mounted smoo'),
(21, 'Travel Bag 3', 6, '4000', 'uploads/travel bag 3.jpg', 'Red textured hardside check-in trolley suitcase, secured with a TSA combination lock\r\nNo. of wheels: 4\r\nOne handle on top and one on the side\r\nPush button trolley\r\n360 degree wheeling system\r\nPush but'),
(22, 'Travel Bag 4', 6, '3500', 'uploads/Travel Bag 4.jpg', '  Red textured hardside check-in trolley suitcase, secured with a fixed combination lock\r\nNo. of wheels: 4\r\nOne handle on top and one on the side\r\nPush button trolley\r\n360 degree wheeling system\r\nPush'),
(23, 'Hand Bag 1', 7, '4000', 'uploads/handbags 21.jpg', 'Brown solid shoulder bag, has a zip closure\r\n1 main compartment, 1 external and 3 inner pockets\r\nTablet sleeve: No\r\nTwo Handles with a detachable sling strap\r\nSize & Fit\r\nHeight: 2 '),
(24, 'Hand Bag 2', 7, '4500', 'uploads/handbags 3.jpg', ' Cream White shoulder bag, has a zip closure\r\n1 main compartment, 1 external and 3 inner pockets\r\nTablet sleeve: No\r\nTwo Handles with a detachable sling strap\r\nSize & Fit\r\nHeight: 2   '),
(25, 'Hand Bag 3', 7, '3300', 'uploads/handbags 2.jpg', ' White shoulder bag, has a zip closure\r\n1 main compartment, 1 external and 3 inner pockets\r\nTablet sleeve: No\r\nTwo Handles with a strap\r\nSize & Fit\r\nHeight: 2  '),
(26, 'Hand Bag 4', 7, '3800', 'uploads/handbags 1.jpg', ' Brown Pink solid shoulder bag, has a zip closure\r\n1 main compartment, \r\nTablet sleeve: No\r\nTwo Handles with a detachable sling strap\r\nSize & Fit\r\nHeight: 2   ');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `timestamp` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `password`, `timestamp`) VALUES
(1, 'saurabh@gmail.com', '$2y$10$Yr.7mtA9LQsk/8kStrsmB.WtgEj4N4Ocdn4z0amTevTiUFWe6kOZm', '2021-03-01 20:13:01'),
(2, 'test@gmail.com', '$2y$10$hJawAC7L3NoHXzdlwqmLI.CB.4PwvUY4sfmQP43g28/mrq1xNbd/6', '2021-03-07 10:38:52'),
(3, 'abc@gmail.com', '$2y$10$sZG0mjEDzI.vmsorZlG1/OSb5niFZEM6QHf9A62lSYbucRWACtqDi', '2021-03-22 19:15:39'),
(4, 'parvez@gmail.com', '$2y$10$TW341KjDc.exzr.Ak.wKROC29VV8aImF110df3KGk9YLHFDAaBG.C', '2021-03-26 16:16:56'),
(5, 'test2@gmail.com', '$2y$10$sQoaWoazzkI2xrL2qPZDs.xFoAS6nfviFSqCpoCYheSv1pZuFftxK', '2021-03-27 11:39:25'),
(6, 'test3@gmail.com', '$2y$10$h0mqpLfGKsN5pR/ez9McZO.KbzqZnLxLxKcGlrKSaa8pPaSKWmmZO', '2021-03-27 11:43:00'),
(7, 'test4@gmail.com', '$2y$10$hEDe.SnTWcQcMHvFno7TI.LPvNCqWq9qYYAaF0XYQzVqhsN1rdRme', '2021-03-27 11:43:46'),
(8, 'test5@gmail.com', '$2y$10$QxZYPqv1lzw5Dl4TXPBNdepa71c8lZSwdKC7UVzq14Oe1IIrV0R0.', '2021-03-27 16:17:07');

-- --------------------------------------------------------

--
-- Table structure for table `user_data`
--

CREATE TABLE `user_data` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `firstname` varchar(200) NOT NULL,
  `lastname` varchar(200) NOT NULL,
  `company` varchar(200) NOT NULL,
  `address1` varchar(200) NOT NULL,
  `address2` varchar(200) NOT NULL,
  `city` varchar(200) NOT NULL,
  `country` varchar(200) NOT NULL,
  `zip` int(11) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `cardname` varchar(255) NOT NULL,
  `cardnumber` int(50) NOT NULL,
  `cvv` int(50) NOT NULL,
  `expmonth` char(50) NOT NULL,
  `expyear` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_data`
--

INSERT INTO `user_data` (`id`, `userid`, `firstname`, `lastname`, `company`, `address1`, `address2`, `city`, `country`, `zip`, `mobile`, `cardname`, `cardnumber`, `cvv`, `expmonth`, `expyear`) VALUES
(4, 4, 'parvez', 'shaikh', 'sdda', 'sdad', 'asdad', 'dsada', '', 422112, '9100900909', 'dsddSdaddd', 2147483647, 123, '12', 4),
(5, 2, 'saurabh', 'jadhav', 'modern', 'ambernath near navre park', 'room no 304', 'ambernath', '', 421505, '8805678009', '', 2147483647, 123, '04', 25),
(6, 7, 'testnew', 'jadhav', 'testing', 'test', 'test304', 'amb', 'AX', 421505, '8805789800', 'test', 2147483647, 123, '04', 25),
(7, 8, 'saurabh', 'jadhav', 'test', 'navre park', 'room no 304', 'ambernath', 'AX', 421505, '9999999999', '', 2147483647, 123, '02', 25);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_data`
--
ALTER TABLE `admin_data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ordersitems`
--
ALTER TABLE `ordersitems`
  ADD PRIMARY KEY (`orderid`);

--
-- Indexes for table `orderstracking`
--
ALTER TABLE `orderstracking`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `user_data`
--
ALTER TABLE `user_data`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_data`
--
ALTER TABLE `admin_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `cat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;

--
-- AUTO_INCREMENT for table `ordersitems`
--
ALTER TABLE `ordersitems`
  MODIFY `orderid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;

--
-- AUTO_INCREMENT for table `orderstracking`
--
ALTER TABLE `orderstracking`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `user_data`
--
ALTER TABLE `user_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
