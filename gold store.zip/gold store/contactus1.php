<?php include('inc/nav.php') ?>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-T8Gy5hrqNKT+hzMclPo118YTQO6cYprQmhrYwIiQ/3axmI1hQomh7Ud2hPOy8SP1" crossorigin="anonymous">

<section class="contact py-5 bg-warning" id="contact">
<div class="container">
	<div class="row">
	    <div class="col-md-12">
	        <h4>Get in touch</h4>
		    <hr>
	    </div>
		<div class="col-md-6">
		    <div class="address">
		        
		    <h5>Address:</h5>
		    <ul class="list-unstyled">
		        <li>ornaments Store</li>
		        <li> Pin 421505</li>
		        <li> Ambernath (West)</li>
		    </ul>
		    <p></p>
		    </div>
		    <div class="email">
		    <h5>Email:</h5>
		    <ul class="list-unstyled">
		        <li> ornaments@gmail.com</li>
		        <li> ornaments@gmail.com</li>
		    </ul>
		    </div>
		    <div class="phone">
		        <h5>Phone:</h5>
		        <ul class="list-unstyled">
		        <li> +91- 8800XXXXXX34</li>
		        <li> +91- 8800XXXXXX34</li>
		    </ul>
		    </div>
		    <hr>
		    <div class="social">
	        <ul class="list-inline list-unstyled">
	            <li class="list-inline-item">
	                <a href="#"><i class="fa fa-facebook-square fa-2x"></i></a>
	            </li>
	            <li class="list-inline-item">
	                <a href="#"><i class="fa fa-google-plus-square fa-2x"></i></a>
	            </li>
	            <li class="list-inline-item">
	                <a href="#"><i class="fa fa-youtube-play fa-2x"></i></a>
	            </li>
	        </ul>
	    </div>
		</div>
	
	
	
</div>
</section>